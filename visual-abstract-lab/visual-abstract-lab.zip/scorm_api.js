/**
 * SCORM 1.2 API Wrapper
 * Visual Abstract Lab — Gruppe 3
 * Kompatibel mit Moodle, SCORM Cloud, ILIAS
 */

var SCORM = (function () {

  var _API = null;
  var _initialized = false;
  var _finished = false;
  var _debug = false; // auf true setzen für Console-Logs

  /* ── API finden ─────────────────────────────────── */
  function _findAPI(win) {
    var attempts = 0;
    while (!win.API && win.parent && win.parent !== win && attempts < 10) {
      win = win.parent;
      attempts++;
    }
    return win.API || null;
  }

  function _getAPI() {
    if (_API) return _API;
    _API = _findAPI(window);
    if (!_API && window.opener) _API = _findAPI(window.opener);
    if (_debug && !_API) console.warn('[SCORM] Kein LMS-API gefunden — Offline-Modus aktiv.');
    return _API;
  }

  /* ── Basis-Calls ─────────────────────────────────── */
  function _call(fn, param) {
    var api = _getAPI();
    if (!api) return '';
    try {
      var result = (param !== undefined) ? api[fn](param) : api[fn]('');
      if (_debug) console.log('[SCORM] ' + fn + '(' + (param||'') + ') =', result);
      return result;
    } catch (e) {
      console.error('[SCORM] Fehler bei ' + fn + ':', e);
      return '';
    }
  }

  /* ── Öffentliche API ─────────────────────────────── */
  function initialize() {
    if (_initialized) return true;
    var result = _call('LMSInitialize');
    _initialized = (result === 'true' || result === true);
    if (_debug) console.log('[SCORM] Initialize:', _initialized);
    return _initialized;
  }

  function finish() {
    if (_finished || !_initialized) return;
    _call('LMSCommit');
    _call('LMSFinish');
    _finished = true;
    if (_debug) console.log('[SCORM] Finish aufgerufen.');
  }

  function setValue(key, value) {
    if (!_initialized) return;
    _call('LMSSetValue', key);
    // Manche APIs brauchen zwei Argumente
    var api = _getAPI();
    if (!api) return;
    try { api.LMSSetValue(key, value); } catch(e) {}
    _call('LMSCommit');
  }

  function getValue(key) {
    if (!_initialized) return '';
    var api = _getAPI();
    if (!api) return '';
    try { return api.LMSGetValue(key); } catch(e) { return ''; }
  }

  function commit() {
    if (!_initialized) return;
    _call('LMSCommit');
  }

  /* ── Convenience-Methoden ────────────────────────── */

  // Score: raw 0–100, min 0, max 100
  function setScore(raw, min, max) {
    var api = _getAPI();
    if (!api || !_initialized) return;
    try {
      api.LMSSetValue('cmi.core.score.raw',   String(raw));
      api.LMSSetValue('cmi.core.score.min',   String(min !== undefined ? min : 0));
      api.LMSSetValue('cmi.core.score.max',   String(max !== undefined ? max : 100));
      api.LMSCommit('');
    } catch(e) {}
  }

  // Status: 'passed' | 'failed' | 'completed' | 'incomplete' | 'browsed' | 'not attempted'
  function setStatus(status) {
    var api = _getAPI();
    if (!api || !_initialized) return;
    try {
      api.LMSSetValue('cmi.core.lesson_status', status);
      api.LMSCommit('');
    } catch(e) {}
  }

  // cmi.interactions — SCORM 1.2 Interaction speichern
  // type: 'true-false' | 'choice' | 'fill-in' | 'matching' | 'performance' | 'sequencing' | 'likert' | 'numeric'
  // result: 'correct' | 'wrong' | 'unanticipated' | 'neutral'
  function setInteraction(index, id, type, response, result, description) {
    var api = _getAPI();
    if (!api || !_initialized) return;
    var n = String(index);
    try {
      api.LMSSetValue('cmi.interactions.' + n + '.id',               id.substring(0, 255));
      api.LMSSetValue('cmi.interactions.' + n + '.type',             type);
      api.LMSSetValue('cmi.interactions.' + n + '.student_response', String(response).substring(0, 255));
      api.LMSSetValue('cmi.interactions.' + n + '.result',           result);
      // description ist optional — nicht alle LMS unterstützen es
      try { api.LMSSetValue('cmi.interactions.' + n + '.description', String(description||'').substring(0, 255)); } catch(e) {}
      api.LMSCommit('');
    } catch(e) {
      if (_debug) console.warn('[SCORM] Interaction ' + n + ' konnte nicht gesetzt werden:', e);
    }
  }

  function isConnected() { return !!_getAPI(); }

  return {
    initialize:      initialize,
    finish:          finish,
    setValue:        setValue,
    getValue:        getValue,
    commit:          commit,
    setScore:        setScore,
    setStatus:       setStatus,
    setInteraction:  setInteraction,
    isConnected:     isConnected
  };

})();
